//
//  ViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/2/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {
    //var listOfUsers = [Usuarios]()
    
    let decodeSesion = JSONDecoder()
    let defaults = UserDefaults.standard
    
    @IBOutlet weak var user: UITextField!
    

    
    @IBOutlet weak var clave: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        print("gato")
        
        
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindView (segue: UIStoryboardSegue){
    }
    override func viewDidAppear(_ animated: Bool) {
        let defaults = UserDefaults.standard
        
        if let dato = defaults.object(forKey: "logIn")  {
            let decodeSesion = try? JSONDecoder().decode(login.self, from: dato as! Data)
            if decodeSesion?.estado == true {
                //print("gatitooooooooooooja")
                performSegue(withIdentifier: "SignIn", sender: nil)
            }
            
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        user.text = ""
        clave.text = ""
       
        
        
    }
    
    @IBAction func SignIn(_ sender: UIButton) {
        guard let correo = user.text,
            let pass = clave.text else { return }
        let db = Firestore.firestore()
        let settings = db.settings
        settings.areTimestampsInSnapshotsEnabled = true
        db.settings = settings
        Auth.auth().signIn(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            } else {
                let logIn = Firestore.firestore().collection("users")
                logIn.whereField("email", isEqualTo: correo).getDocuments() { (querySnapshot, err) in
                    if let err = err {
                        print("Error getting documents: \(err)")
                    } else {
                        for document in querySnapshot!.documents {
                            print(document.data())
                            let dato = document.data()
                            let LogInId = dato["id"] as! String
                            //var LOGIN = [login]()
                            let LOGIN = login(id: LogInId, estado: true)
                            print(LOGIN)
                            //self.notRegistered()
                            let encodeData = try? JSONEncoder().encode(LOGIN)
                            self.defaults.set(encodeData, forKey: "logIn")
                            
                        }
                    }
                }
                self.performSegue(withIdentifier: "SignIn", sender: nil )
            }
        }
       //performSegue(withIdentifier: "SignIn", sender: nil)
        /*
        let defaults = UserDefaults.standard
        if let dato = defaults.object(forKey: "list"), let nombre = user.text, let cl = clave.text{
            let decodeData = try? JSONDecoder().decode([Usuarios].self, from: dato as! Data)
            for i in decodeData!{
                if i.nameOfUsuario == nombre && i.password == cl{
                    var logIn = i
                    logIn.estado = true
                    print(logIn.nameOfUsuario)
                    let encodeData = try? JSONEncoder().encode(logIn)
                    defaults.set(encodeData, forKey: "logIn")
                    performSegue(withIdentifier: "SignIn", sender: nil)
                }
            }
            notRegistered()
            
            //user.text = "No estas regristado"
        }else{
            notRegistered()
            //user.text = "No estas registrado"
            //print("No estas registrado")
        }*/
    }
    func notRegistered() {
        
        let alertVC = UIAlertController(title: "Wop", message: "It seems that you are not registered", preferredStyle: .alert)
        
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel) { action in
            
            
        }
        
        
        
        alertVC.addAction(okAction)
        
        
        self.present(alertVC, animated: true, completion: nil)
    }
    func logInfunc (logInSesion a: login){
        
    }
    
    
}
