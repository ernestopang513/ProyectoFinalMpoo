//
//  ScoreListViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/3/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase

class ScoreListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var imagen: UIImageView!
    
    struct vato{
        var name: String
        var score: Int
        var id: String
        var school: String
        var categoria: String
    }
    
    @IBOutlet weak var table: UITableView!
    
    
    var listOfUsers = [vato]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        listOfUsers.append(Usuarios(name: "Ernesto", score: "6040"))
        listOfUsers.append(Usuarios(name: "Ian", score: "4000"))
        listOfUsers.append(Usuarios(name: "Juan", score: "3000"))
 */
        
        
        //table.reloadData()
        
    
        



        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        let userRef = Firestore.firestore().collection("users")
        userRef.addSnapshotListener(){ (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                self.listOfUsers.removeAll()
                for document in querySnapshot!.documents {
                    //print("\(document.documentID) => \(document.data())")
                    let data = document.data()
                    let NameOfUser = data["username"] as! String
                    let score = data["score"] as! Int
                    let ID = data["id"] as! String
                    let school = data["school"] as! String
                    let category = data["categoria"] as! String
                    let newDude = vato(name: NameOfUser, score: score, id: ID, school: school, categoria: category)
                    self.listOfUsers.append(newDude)
                }
            }
            self.table.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listOfUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CustomTableViewCell
        cell2.labelCell1.text = "\(listOfUsers[indexPath.row].name)"
        cell2.labelCell2.text = "Score: \(listOfUsers[indexPath.row].score)"
        //cell2.imageCell.image = #imageLiteral(resourceName: "Platano")
        switch listOfUsers[indexPath.row].categoria {
        case "Platano":
            cell2.imageCell.image = #imageLiteral(resourceName: "Platano")
        case "Oro":
            cell2.imageCell.image = #imageLiteral(resourceName: "Oro")
        case "Diamante":
            cell2.imageCell.image = #imageLiteral(resourceName: "diamante")
        default:
            print("Error")
        }
        return cell2
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "info"{
            let indexPath = table.indexPathForSelectedRow
            let destination = segue.destination as! InfoViewController
            //destination.vatito = listOfUsers[(indexPath?.row)!]
            destination.name = listOfUsers[(indexPath?.row)!].name
            destination.score = listOfUsers[(indexPath?.row)!].score
            destination.school = listOfUsers[(indexPath?.row)!].school
            destination.id = listOfUsers[(indexPath?.row)!].id
            destination.categoria = listOfUsers[(indexPath?.row)!].categoria
        }
    }
    
   
 
    
}
