//
//  SignUpViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/2/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase

class SignUpViewController: UIViewController {
    
    //var lista = [Usuarios]()
    @IBOutlet weak var nombre: UITextField!
    
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //let defaults = UserDefaults.standard
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func signUp(_ sender: UIButton) {
        
        let nop = email.text
        let nop2 = password.text
        let nop3 = nombre.text
        guard let correo = email.text, nop?.count != 0, nop2?.count != 0, nop3?.count != 0, let pass = password.text, let username = nombre.text else {
                FillInAllTheFields()
               
                return
                
        }
        print(correo)
        Auth.auth().createUser(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            }
            
            let user = data?.user
            let changeRequest = user?.createProfileChangeRequest()
            changeRequest?.displayName = username
            changeRequest?.commitChanges(completion: { (error) in
                if let error = error{
                    debugPrint(error.localizedDescription)
                }
            })
            
            guard let userId = user?.uid else { return }
            
            Firestore.firestore().collection("users").document(userId).setData([
                "username" : username,
                "id" : userId,
                "email" : correo,
                "date_created": FieldValue.serverTimestamp(),
                "estado" : false,
                "school" : "",
                "score" : 0,
                "matricula" : "",
                "verificado" : false,
                "categoria" : "Platano"
                
                ], completion: { (error) in
                    if let error = error {
                        debugPrint(error)
                    }
            })
            self.OK()
        }
    }
    
     func PasswordsDoNotMatch() {
        
        let alertVC = UIAlertController(title: "Upss", message: "Passwords do not match", preferredStyle: .alert)
        
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel) { action in
            
           
        }
        
        
        
        alertVC.addAction(okAction)
        
        
        self.present(alertVC, animated: true, completion: nil)
    }
    func FillInAllTheFields() {
        
        let alertVC = UIAlertController(title: "Wop", message: "Fill in all the fields", preferredStyle: .alert)
        
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel) { action in
            
            
        }
        
        
        
        alertVC.addAction(okAction)
        
        
        self.present(alertVC, animated: true, completion: nil)
    }
    func OK() {
        
        let alertVC = UIAlertController(title: "Perfect", message: "You are registered", preferredStyle: .alert)
        
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel) { action in
            
        }
        
        
        
        alertVC.addAction(okAction)
        
        
        self.present(alertVC, animated: true, completion: nil)
    }
    func update() {
        
        
        let alertVC = UIAlertController(title: "Perfect", message: "It is done!", preferredStyle: .alert)
        
        
        
        let okAction = UIAlertAction(title: "Ok", style: .default) { action in
            
            
        }
        
        
        
        alertVC.addAction(okAction)
        
        
        self.present(alertVC, animated: true, completion: nil)
    }

    @IBOutlet weak var user: UILabel!
    
    @IBOutlet weak var clave: UILabel!
    
}
