//
//  ExamViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/4/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase

class ExamViewController: UIViewController {

    struct question {
        var content: String
        var a: String
        var b: String
        var c: String
        var d: String
        var resp: String
    }
    var list = [question]()
    var i = 0
    var aciertos = 0
    var errores = 0
    var updatescore = 0
    
    var questionCollectionRef = Firestore.firestore().collection("Question")
    @IBOutlet weak var D: UITextView!
    @IBOutlet weak var C: UITextView!
    @IBOutlet weak var A: UITextView!
    @IBOutlet weak var B: UITextView!
    @IBOutlet weak var Op1: ButtonCustom!
    @IBOutlet weak var Op2: ButtonCustom!
    @IBOutlet weak var Op3: ButtonCustom!
    @IBOutlet weak var Op4: ButtonCustom!
    @IBOutlet weak var contentQuestion: UITextView!
    @IBOutlet var aviso: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        questionCollectionRef = Firestore.firestore().collection("Question")
        questionCollectionRef.getDocuments { (snapshot, error) in
            if let error = error{
                debugPrint(error)
            }else{
                self.list.removeAll()
                for document in (snapshot?.documents)!{
                    let data = document.data()
                    let content = data["content"] as! String
                    let a = data["a"] as! String
                    let b = data["b"] as! String
                    let c = data["c"] as! String
                    let d = data["d"] as! String
                    let answer = data["answer"] as! String
                    let newQuestion = question(content: content, a: a, b: b, c: c, d: d, resp: answer)
                    //print(newQuestion)
                    self.list.append(newQuestion)
                    //print(self.list)
                }
                //print(self.list)
                self.animateIn()
                
            }
        }
        //print(list)
        //animateIn()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func animateIn() {
        contentQuestion.text = list[i].content
        A.text = list[i].a
        B.text = list[i].b
        C.text = list[i].c
        D.text = list[i].d
        self.view.addSubview(aviso)
        aviso.center = self.view.center
        //self.view.backgroundColor = UIColor.red
        aviso.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        aviso.alpha = 0
        UIView.animate(withDuration: 0.6){
            self.aviso.alpha = 1
            self.aviso.transform = CGAffineTransform.identity
        }
    }
    func animateOut(){
        update()
     
        
        UIView.animate(withDuration: 0.3, animations:{
            self.aviso.transform = CGAffineTransform.init(scaleX: 1.3 ,y: 1.3 )
            self.aviso.alpha = 0
            //self.efectovisual.effect = nil
        } ){(success: Bool) in
            self.aviso.removeFromSuperview()
        }
    }
    
    
    func OK() {
        
        let alertVC = UIAlertController(title: "Calificacion \(aciertos)", message: "Haz terminado el examen", preferredStyle: .alert)
        
        
        let okAction = UIAlertAction(title: "Ok", style: .cancel) { action in
            
            
        }
        
        
        
        alertVC.addAction(okAction)
        
        
        self.present(alertVC, animated: true, completion: nil)
    }
    
    @IBAction func nextQuestion(_ sender: UIButton) {
        //animateOut()
        /*
         if  let answer2 = answer.text {
         if list[i].resp == answer2{
         aciertoss += 1
         }else{
         erroress += 1
         }
         }
         */
        i += 1
        //var i = 1
        
        contentQuestion.text = list[i].content
        Op1.backgroundColor = UIColor.white
        Op2.backgroundColor = UIColor.white
        Op3.backgroundColor = UIColor.white
        Op4.backgroundColor = UIColor.white
        //aciertos.text = "Aciertos \(aciertoss)"
        //errores.text = "Errores \(erroress)"
        animateIn()
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    @IBAction func option1(_ sender: UIButton) {
        


            let op1 = "a"
            if op1 == list[i].resp{
                aciertos += 10
            }else{
                errores += 10
            }
        
            print(aciertos + errores)
            print("tope")
            print(i)
            //print(errores)
            if errores + aciertos == 100 {
                print(errores + aciertos)
                OK()
                animateOut()
            }else{
                i += 1
                animateIn()
        }
        
        
    }
    
    
    @IBAction func option2(_ sender: UIButton) {
        let option = "b"
        if option == list[i].resp{
            aciertos += 10
        }else{
            errores += 10
        }
        if errores + aciertos == 100 {
            OK()
            animateOut()
        
        }else{
            
            i += 1
            animateIn()
        }
        
    }
    @IBAction func option3(_ sender: UIButton) {
        let option = "c"
        if option == list[i].resp{
            aciertos += 10
        }else{
            errores += 10
        }
        if errores + aciertos == 100 {
            OK()
            animateOut()
        }else{
            
            i += 1
            animateIn()
        }
        
        
    }
    @IBAction func option4(_ sender: UIButton) {
        let option = "d"
        if option == list[i].resp{
            aciertos += 10
        }else{
            errores += 10
        }
        if errores + aciertos == 100 {
            OK()
            animateOut()
            return
        }else{
            
            i += 1
            animateIn()
        }
        
    }
    func update() {
        let dato = UserDefaults.standard.object(forKey: "logIn")
        let decodeSesion = try? JSONDecoder().decode(login.self, from: dato as! Data)
        let ID = decodeSesion?.id
        let referencia = Firestore.firestore().collection("users")
        
        referencia.whereField("id", isEqualTo: ID!).getDocuments(){ (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for documents in querySnapshot!.documents{
                    let data = documents.data()
                    
                    let score = data["score"] as! Int
                    self.updatescore = score + self.aciertos
                    referencia.document(ID!).updateData(["score": self.updatescore]){ err in
                        if let err = err {
                            print("Error updating document: \(err)")
                        } else {
                            print("Document successfully updated")
                        }
                    }
                    
                }
            }
        }
        
        
    }
    
    
}

