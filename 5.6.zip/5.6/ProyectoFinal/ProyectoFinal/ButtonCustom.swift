//
//  ButtonCustom.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 28/11/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class ButtonCustom: UIButton {
    
    override func awakeFromNib() {
        layer.borderWidth = 3.0
        layer.borderColor = UIColor.black.cgColor
        layer.cornerRadius = 20
        layer.masksToBounds = true
        
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
