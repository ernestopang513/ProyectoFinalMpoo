//
//  UploadQuestions.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 29/11/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase

class UploadQuestions: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        var list = [question]()
        list.append(question(content: """
           When this code is executed, what will the third constant contain?
        let first = ["Sulaco", "Nostromo"]
        let second = ["X-Wing", "TIE Fighter"]
        let third = first + second
        """, a: """
            a)"Sulaco", "Nostromo"
            """,
             
             b: """
            b)"Sulaco", "Nostromo", "Sulaco", "Nostromo"
            """,
             
             c: "c)This code will compile but crash",
             
             d: """
            d)"Sulaco", "Nostromo", "X-Wing", "TIE Fighter"
            """
            , resp: "d"))
        list.append(question(content: """
        When this code is executed, what is the value of the swift string?
        import Foundation
        let ns = NSString("Hello")
        let swift = String(ns)
        """, a: "a) This code will not compile.", b: "b) Hello", c: "String(Hello)", d: "Will compile but nothing will appear", resp: "a"))
        list.append(question(content: """
        What output will be produced by the code below?ç
        var i = 2
        repeat {
        i *= i * 2
        } while i < 100
        print(i)
        """, a: "2", b: "182", c: "128", d: "6", resp: "c"))
        list.append(question(content: """
        El atomo es la parte mas pequena de la __________ que conserva las propiedades.
        """, a: "Materia", b: "Energia", c: "Sustancia", d: "Mezcla", resp: "a"))
        list.append(question(content: """
        What output will be produced by the code below?
        let i = 3
        switch i {
        case 1:
        print("Number was 1")
        case 2:
        print("Number was 2")
        case 3:
        print("Number was 3")
        }
        """, a: "This code will not compile.", b: "he number is 2", c: "The number is 1", d: "The number is 3", resp: "a"))
        list.append(question(content: """
        La sal de mesa es:
        """, a: "Un elemento quimico", b: "Una mezcla", c: "Una sustancia", d: "Un producto dietetico", resp: "c"))
        list.append(question(content: """
        What output will be produced by the code below?
        class Starship {
        var type: String
        var age: Int
        }
        let serenity = Starship(type: "Firefly", age: 24)
        print(serenity.type)
        """, a: "This code will compile but crash.", b: "This code will not compile.", c: "Firefly", d: "24", resp: "b"))
        list.append(question(content: """
        When this code is executed, what value will num have?
        let num = UInt.min
        """, a: "5", b: "255", c: "0", d: "90", resp: "c"))
        list.append(question(content: """
        What output will be produced by the code below?
        var motto = "Bow ties are cool"
        motto.replacingOccurrences(of: "Bow", with: "Neck")
        print(motto)
        """, a: "Bow ties are", b: "ties are cool", c: "Bow ties are cool", d: ")Bow ties cool", resp: "c"))
        list.append(question(content: """
        When this code is executed, what will be the value of the j constant?
        let i = "5"
        let j = i + i
        """, a: "55", b: "5", c: "555", d: "5555", resp: "a"))
        
        
        for i in 0...9{
            Firestore.firestore().collection("Question").document(String(i)).setData([
                
                
                "content": list[i].content,
                
                "a": list[i].a,
                "b": list[i].b,
                "c": list[i].c,
                "d": list[i].d,
                
                "answer" : list[i].resp
                
                
                ], completion: { (error) in
                    if let error = error {
                        debugPrint(error)
                    }
            })
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
