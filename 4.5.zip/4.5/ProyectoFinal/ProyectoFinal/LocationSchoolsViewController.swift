//
//  LocationSchoolsViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 01/12/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class LocationSchoolsViewController: UIViewController {
    
    var school: String = ""
    @IBOutlet weak var selectedSchool: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedSchool.text = school
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
