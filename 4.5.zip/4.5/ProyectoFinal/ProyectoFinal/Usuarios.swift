//
//  Usuarios.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/2/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import Foundation

struct Usuarios: Codable{
    var nameOfUsuario: String
    var password: String
    var estado: Bool
    var school: String
    var score: Double
    var matricula: String
    var verificado: Bool
}

struct login : Codable{
    var id: String
    var estado: Bool
}

struct question {
    var content: String
    var a: String
    var b: String
    var c: String
    var d: String
    var resp: String
}
/*
 struct Questions{
 var pregunta: String
 var opciones: String
 var resp: String
 var Resultado: Bool
 }
 */

