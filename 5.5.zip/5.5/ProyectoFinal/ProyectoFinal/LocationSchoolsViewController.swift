//
//  LocationSchoolsViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 01/12/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import MapKit

class LocationSchoolsViewController: UIViewController {
    
    var school: String = ""
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var selectedSchool: UILabel!
    
    @IBOutlet weak var info: UITextView!
    
    @IBOutlet weak var escudo: UIImageView!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        selectedSchool.text = school
        switch school {
        case "Facultad de Ingenieria":
            let latitude = 19.3276
            let longitude = -99.1824
            let informacion =
            """
            Numero de contacto: ?
            
            Direccion:
            Universidad Nacional Autónoma de México
            Av Universidad 3000
            Ciudad Universitaria
            04510 Coyoacán, CDMX
            México
            
            Pagina Web: http://ioslab.ingenieria.unam.mx
            """
            info.text = informacion
            escudo.image = #imageLiteral(resourceName: "Fi")
            findSchool(lat: latitude, long: longitude)
        case "Facultad de Contaduria":
            let latitude = 19.3238
            let longitude = -99.1859
            let informacion =
            """
            Numero de contacto: Creo que no hay
            
            Direccion:
            Facultad de Contaduria y Administracion
            Circuito Exterior
            Ciudad Universitaria
            04510 Coyoacán, CDMX
            México
            
            
            """
            info.text = informacion
            escudo.image = #imageLiteral(resourceName: "Fca")
            findSchool(lat: latitude, long: longitude)
        case "Some school":
            let latitude = 0.1
            let longitude = 0.1
            let informacion =
            """
            Numero de contacto: ?
            
            Direccion:  En alguna Fes
            
            Pagina Web: ?
            
            """
            info.text = informacion
            escudo.image = #imageLiteral(resourceName: "Unam")
            findSchool(lat: latitude, long: longitude)
        default:
            print("error")
        }
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func findSchool (lat a: Double, long b: Double){
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.001, 0.001)
        let location:CLLocationCoordinate2D = CLLocationCoordinate2DMake(a,b)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(location,span)
        map.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        
        annotation.coordinate = location
        annotation.title = school
        annotation.subtitle = "Unam"
        map.addAnnotation(annotation)
        
    }

}
