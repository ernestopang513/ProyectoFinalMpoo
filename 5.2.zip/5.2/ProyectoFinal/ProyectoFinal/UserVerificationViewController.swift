//
//  UserVerificationViewController.swift
//  ProyectoFinal
//
//  Created by MacBook on 07/11/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase

class UserVerificationViewController: UIViewController , UIPickerViewDelegate, UIPickerViewDataSource{
    
    let Schools = ["Facultad de Ingenieria", "Facultad de Contaduria"]
    
    
    
    
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var matricula: UITextField!
    
    @IBOutlet weak var school: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func verificationAction(_ sender: UIButton) {
        guard let matricula = matricula.text,school.text != "Escoge tu Facultad" , let school = school.text else {return}
        let defaults = UserDefaults.standard
        guard let dato = defaults.object(forKey: "logIn") else {
            return
        }
        let decodeSesion = try! JSONDecoder().decode(login.self, from: dato as! Data)
        let UserId = decodeSesion.id
        let userRef = Firestore.firestore().collection("users")
        userRef.document(UserId).updateData(["school": self.school.text!, "matricula": self.matricula.text!, "verificado": true]){ err in
            if let err = err {
                print("Error updating document: \(err)")
            } else {
                print("Document successfully updated")
            }
        }
        
        /*
        userRef.whereField("id", isEqualTo: UserId ).getDocuments(){ (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for documents in querySnapshot!.documents{
                    let data = documents.data()
                    let date_created = data["date_created"] as! Date
                    let email = data["email"] as! String
                    let estado = data["estado"] as! Bool
                    let id = data["id"] as! String
                    //let matricula = matricula
                    //let school = school
                    let score = data["score"] as! Int
                    let username = data["username"] as! String
                    //let verificado = data["verificado"] as! Bool
                    Firestore.firestore().collection("users").document(id).setData([
                        "username" : username,
                        "id" : id,
                        "email" : email,
                        "date_created": date_created,
                        "estado" : estado,
                        "school" : school,
                        "score" : score,
                        "matricula" : matricula,
                        "verificado" : true
                        
                        ], completion: { (error) in
                            if let error = error {
                                debugPrint(error)
                            }
                    })
                }
            }
                
                
            }
            */
            /*
            if school.text?.count != 0 && matricula.text?.count != 0 {
            let schooll = school.text
            let matric = matricula.text
            let defaults = UserDefaults.standard
            if let dato = defaults.object(forKey: "logIn")  {
                var decodeSesion = try? JSONDecoder().decode(Usuarios.self, from: dato as! Data)
                decodeSesion?.school = schooll!
                decodeSesion?.matricula = matric!
                decodeSesion?.verificado = true
                decodeSesion?.score = 1.1
                let encodeSesion = try? JSONEncoder().encode(decodeSesion)
                defaults.set(encodeSesion, forKey: "logIn")
            }
        }
                */
                
 
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Schools.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Schools[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        school.text = Schools[row]
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
