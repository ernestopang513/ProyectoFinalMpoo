//
//  InfoViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 04/12/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class InfoViewController: UIViewController {
    
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Score: UILabel!
    @IBOutlet weak var ImagenCategory: UIImageView!
    
    @IBOutlet weak var imageApp: UIImageView!
    @IBOutlet weak var Emblema: UIImageView!
    @IBOutlet weak var Category: UILabel!
    @IBOutlet weak var School: UILabel!
    var name = ""
    var score = 2
    var id = ""
    var school = ""
    var categoria = ""
    
    //var vatito = vato(name: , score: s, id: "", school: "", categoria: "")

    override func viewDidLoad() {
        super.viewDidLoad()
        Name.text = name
        Score.text = String(score)
        School.text = school
        Category.text = categoria
        imageApp.image = #imageLiteral(resourceName: "imageApp")
        rango(categoria: categoria)
        BuscaEscudo(escudo: school)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func rango(categoria a:String){
        switch a {
        case "Platano":
            ImagenCategory.image = #imageLiteral(resourceName: "Platano")
        case "Oro":
            ImagenCategory.image = #imageLiteral(resourceName: "Oro")
        case "Diamante":
            ImagenCategory.image = #imageLiteral(resourceName: "diamante")
        default:
            print("Error")
        }
    }
    func BuscaEscudo(escudo a: String){
    switch school {
        case "Facultad de Ingenieria":
        
            Emblema.image = #imageLiteral(resourceName: "Fi")
        
        case "Facultad de Contaduria":
        
            Emblema.image = #imageLiteral(resourceName: "Fca")
        
        case "Some school":
        
        
            Emblema.image = #imageLiteral(resourceName: "Unam")
        
        default:
            print("error")
    }
    }


}
