//
//  TestViewController.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/2/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit
import Firebase
class TestViewController: UIViewController {
    
 
    var list = [question]()
    var i = 0
    var questionCollectionRef = Firestore.firestore().collection("Question")
    //@IBOutlet weak var answer: UITextField!
    //@IBOutlet weak var errores: UILabel!
    //@IBOutlet weak var aciertos: UILabel!
    @IBOutlet weak var contentQuestion: UITextView!
    @IBOutlet var aviso: UIView!
    @IBOutlet weak var Op1: UIButton!
    @IBOutlet weak var Op4: UIButton!
    
    @IBOutlet weak var A: UITextView!
    @IBOutlet weak var B: UITextView!
    
    @IBOutlet weak var D: UITextView!
    @IBOutlet weak var C: UITextView!
    @IBOutlet weak var Op2: UIButton!
    @IBOutlet weak var Op3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        list.append(question(content: """
           When this code is executed, what will the third constant contain?
        let first = ["Sulaco", "Nostromo"]
        let second = ["X-Wing", "TIE Fighter"]
        let third = first + second
        """, a: """
            a)"Sulaco", "Nostromo"
            """,
             
             b: """
            b)"Sulaco", "Nostromo", "Sulaco", "Nostromo"
            """,
             
             c: "c)This code will compile but crash",
             
             d: """
            d)"Sulaco", "Nostromo", "X-Wing", "TIE Fighter"
            """
            , resp: "d"))
        list.append(question(content: """
        When this code is executed, what is the value of the swift string?
        import Foundation
        let ns = NSString("Hello")
        let swift = String(ns)
        """, a: "a) This code will not compile.", b: "b) Hello", c: "String(Hello)", d: "Will compile but nothing will appear", resp: "a"))
        list.append(question(content: """
        What output will be produced by the code below?ç
        var i = 2
        repeat {
        i *= i * 2
        } while i < 100
        print(i)
        """, a: "2", b: "182", c: "128", d: "6", resp: "c"))
        list.append(question(content: """
        El atomo es la parte mas pequena de la __________ que conserva las propiedades.
        """, a: "Materia", b: "Energia", c: "Sustancia", d: "Mezcla", resp: "a"))
        list.append(question(content: """
        What output will be produced by the code below?
        let i = 3
        switch i {
        case 1:
        print("Number was 1")
        case 2:
        print("Number was 2")
        case 3:
        print("Number was 3")
        }
        """, a: "This code will not compile.", b: "he number is 2", c: "The number is 1", d: "The number is 3", resp: "a"))
        list.append(question(content: """
        La sal de mesa es:
        """, a: "Un elemento quimico", b: "Una mezcla", c: "Una sustancia", d: "Un producto dietetico", resp: "c"))
        list.append(question(content: """
        What output will be produced by the code below?
        class Starship {
        var type: String
        var age: Int
        }
        let serenity = Starship(type: "Firefly", age: 24)
        print(serenity.type)
        """, a: "This code will compile but crash.", b: "This code will not compile.", c: "Firefly", d: "24", resp: "b"))
        list.append(question(content: """
        When this code is executed, what value will num have?
        let num = UInt.min
        """, a: "5", b: "255", c: "0", d: "90", resp: "c"))
        list.append(question(content: """
        What output will be produced by the code below?
        var motto = "Bow ties are cool"
        motto.replacingOccurrences(of: "Bow", with: "Neck")
        print(motto)
        """, a: "Bow ties are", b: "ties are cool", c: "Bow ties are cool", d: ")Bow ties cool", resp: "c"))
        list.append(question(content: """
        When this code is executed, what will be the value of the j constant?
        let i = "5"
        let j = i + i
        """, a: "55", b: "5", c: "555", d: "5555", resp: "a"))
        */
        
        //animateIn()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        questionCollectionRef = Firestore.firestore().collection("Question")
        questionCollectionRef.getDocuments { (snapshot, error) in
            if let error = error{
                debugPrint(error)
            }else{
                self.list.removeAll()
                for document in (snapshot?.documents)!{
                    let data = document.data()
                    let content = data["content"] as! String
                    let a = data["a"] as! String
                    let b = data["b"] as! String
                    let c = data["c"] as! String
                    let d = data["d"] as! String
                    let answer = data["answer"] as! String
                    let newQuestion = question(content: content, a: a, b: b, c: c, d: d, resp: answer)
                    //print(newQuestion)
                    self.list.append(newQuestion)
                    //print(self.list)
                }
                print(self.list)
                self.animateIn()
               
            }
        }
        //print(list)
        //animateIn()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func animateIn() {
        contentQuestion.text = list[i].content
        A.text = list[i].a
        B.text = list[i].b
        C.text = list[i].c
        D.text = list[i].d
        self.view.addSubview(aviso)
        aviso.center = self.view.center
        //self.view.backgroundColor = UIColor.red
        aviso.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.3)
        aviso.alpha = 0
        UIView.animate(withDuration: 0.6){
            self.aviso.alpha = 1
            self.aviso.transform = CGAffineTransform.identity
        }
    }
    func animateOut(){
        UIView.animate(withDuration: 0.3, animations:{
            self.aviso.transform = CGAffineTransform.init(scaleX: 1.3 ,y: 1.3 )
            self.aviso.alpha = 0
            //self.efectovisual.effect = nil
        } ){(success: Bool) in
            self.aviso.removeFromSuperview()
        }
    }
    
    
    @IBAction func nextQuestion(_ sender: UIButton) {
        //animateOut()
        /*
        if  let answer2 = answer.text {
            if list[i].resp == answer2{
                aciertoss += 1
            }else{
                erroress += 1
            }
        }
        */
        i += 1
        //var i = 1
 
        contentQuestion.text = list[i].content
        Op1.backgroundColor = UIColor.white
        Op2.backgroundColor = UIColor.white
        Op3.backgroundColor = UIColor.white
        Op4.backgroundColor = UIColor.white
        //aciertos.text = "Aciertos \(aciertoss)"
        //errores.text = "Errores \(erroress)"
        animateIn()
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    @IBAction func option1(_ sender: UIButton) {
        let op1 = "a"
        if op1 == list[i].resp{
            Op1.backgroundColor = UIColor.green
        }else{
            Op1.backgroundColor = UIColor.red
            funcanswer(answer: list[i].resp)
        }
        
    }
    
    
    @IBAction func option2(_ sender: UIButton) {
        let option = "b"
        if option == list[i].resp{
            Op2.backgroundColor = UIColor.green
        }else{
            Op2.backgroundColor = UIColor.red
            funcanswer(answer: list[i].resp)
        }
        
    }
    @IBAction func option3(_ sender: UIButton) {
        let option = "c"
        if option == list[i].resp{
            Op3.backgroundColor = UIColor.green
        }else{
            Op3.backgroundColor = UIColor.red
            funcanswer(answer:  list[i].resp)
        }
    }
    @IBAction func option4(_ sender: UIButton) {
        let option = "d"
        if option == list[i].resp{
            Op4.backgroundColor = UIColor.green
        }else{
            Op4.backgroundColor = UIColor.red
            funcanswer(answer: list[i].resp)
        }
    }
    func funcanswer(answer a: String){
        switch a {
        case "a":
            Op1.backgroundColor = UIColor.green
        case "b":
            Op2.backgroundColor = UIColor.green
        case "c":
            Op3.backgroundColor = UIColor.green
        case "d":
            Op4.backgroundColor = UIColor.green
            
        default:
            print("error")
        }
    }
    

}
