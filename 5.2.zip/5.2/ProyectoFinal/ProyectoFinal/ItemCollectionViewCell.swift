//
//  ItemCollectionViewCell.swift
//  ProyectoFinal
//
//  Created by Ernesto Pang on 11/3/18.
//  Copyright © 2018 Ernesto Pang. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var school: UILabel!
    
    @IBOutlet weak var place: UILabel!
    
    @IBOutlet weak var image: UIImageView!
}
